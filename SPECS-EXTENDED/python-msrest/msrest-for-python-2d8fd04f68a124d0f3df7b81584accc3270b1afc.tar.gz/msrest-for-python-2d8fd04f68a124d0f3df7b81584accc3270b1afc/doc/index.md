<meta http-equiv="refresh" content="0; url=https://docs.microsoft.com/python/api/msrest">
<meta name="robots" content="noindex, nofollow">

<a href="https://docs.microsoft.com/python/api/msrest">
    msrest's documentation has moved from ReadTheDocs to docs.microsoft.com.
</a>
