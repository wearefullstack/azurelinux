The `pkg` directory is deprecated.
Please do not add new packages to this directory.
Existing packages will be moved elsewhere eventually.
