Basic example

Run `promu build` to build the `basic-example` binary