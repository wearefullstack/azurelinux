Crossbuild example

Run `promu crossbuild` to crossbuild for linux-386, linux-amd64, and windows-amd64 platforms.
Output will be in the `.build` directory.

Run `promu crossbuild tarballs` to build platform tarballs.
Output will be in the `.tarballs` directory.
